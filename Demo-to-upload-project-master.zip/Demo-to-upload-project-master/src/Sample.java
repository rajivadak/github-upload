class Sample
{
	public static void main(String arg[])
	{
		System.out.println("Welcome");
	}
}